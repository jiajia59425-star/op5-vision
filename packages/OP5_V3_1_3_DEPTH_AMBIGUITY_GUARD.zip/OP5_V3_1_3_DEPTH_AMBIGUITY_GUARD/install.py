#!/usr/bin/env python3
"""Verified, reversible 8100 fusion-core-only safety patch; no auto restart."""
import argparse, hashlib, json, os, shutil, stat, tempfile, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DST=Path('/home/orangepi/op5_v3_fusion')
UNIT=Path('/etc/systemd/system/op5-v3-fusion-8100.service')
BACK=DST/'backups'/'v313_core_before_depth_guard.py'
LEDGER=DST/'.v313_depth_guard.json'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def manifest():
    m=json.loads((ROOT/'manifest.json').read_text('utf-8'))
    if m.get('version')!='OP5_V3_1_3_DEPTH_AMBIGUITY_GUARD' or sha(ROOT/'fusion_core.py')!=m['new_core_sha256']:
        raise RuntimeError('补丁清单校验失败')
    compile((ROOT/'fusion_core.py').read_bytes(),'fusion_core.py','exec')
    return m

def check():
    m=manifest()
    if not UNIT.is_file() or '# OP5_V3_RADAR_VISION_FUSION_V1' not in UNIT.read_text('utf-8'):
        raise RuntimeError('不是预期8100服务，拒绝升级')
    if not (DST/'config.json').is_file():raise RuntimeError('标定文件缺失')
    for name in ('fusion_core.py','service.py'):
        if not (DST/name).is_file() or (DST/name).is_symlink():raise RuntimeError('核心文件缺失或软链接：'+name)
    if sha(DST/'service.py')!=m['required_service_sha256']:
        raise RuntimeError('现场8100时序服务不是V3.1.2，拒绝覆盖')
    got=sha(DST/'fusion_core.py')
    if got==m['old_core_sha256'] and not LEDGER.exists():status='READY_TO_APPLY'
    elif got==m['new_core_sha256'] and LEDGER.exists():status='ALREADY_APPLIED'
    else:status='MISMATCH_OR_PARTIAL'
    print('8100 V3.1.3深度歧义安全补丁 | 现场状态:',status)
    print('现场融合核心 SHA256:',got)
    print('8100 service.py, config.json, 8093, 8101均不修改')
    return status

def guard_idle():
    for port,path in ((8101,'/api/status'),(8093,'/api/auto/status')):
        with urllib.request.urlopen('http://127.0.0.1:%s%s'%(port,path),timeout=2) as r:obj=json.load(r)
        if port==8101 and (obj.get('armed') is not False or obj.get('stop_pending') is not False):
            raise RuntimeError('8101当前存在授权跟踪/停机待确认，拒绝更改')
        if port==8093 and obj.get('active') is not False:
            raise RuntimeError('8093仍在跟踪，拒绝更改')

def replace(src,dst):
    st=dst.stat()
    fd,tmp=tempfile.mkstemp(prefix='.v313_core_',dir=dst.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(src.read_bytes());f.flush();os.fsync(f.fileno())
        os.chmod(tmp,stat.S_IMODE(st.st_mode))
        if os.geteuid()==0:os.chown(tmp,st.st_uid,st.st_gid)
        os.replace(tmp,dst)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def apply():
    if check()!='READY_TO_APPLY':raise RuntimeError('状态不匹配，未覆盖文件')
    guard_idle()
    m=manifest()
    if BACK.exists():raise RuntimeError('回退备份已存在，不允许覆盖')
    BACK.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(DST/'fusion_core.py',BACK)
    if sha(BACK)!=m['old_core_sha256']:raise RuntimeError('备份核心SHA不匹配')
    ledger={'version':m['version'],'old':m['old_core_sha256'],'new':m['new_core_sha256'],
            'service_sha':sha(DST/'service.py'),'config_sha':sha(DST/'config.json')}
    fd,tmp=tempfile.mkstemp(prefix='.v313_ledger_',dir=DST)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(ledger,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
        os.replace(tmp,LEDGER)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    try:
        replace(ROOT/'fusion_core.py',DST/'fusion_core.py')
        if (sha(DST/'fusion_core.py')!=m['new_core_sha256'] or
            sha(DST/'service.py')!=ledger['service_sha'] or
            sha(DST/'config.json')!=ledger['config_sha']):
            raise RuntimeError('安装后校验失败')
    except Exception:
        replace(BACK,DST/'fusion_core.py');LEDGER.unlink(missing_ok=True)
        raise
    print('INSTALL SUCCESS: 仅8100融合核心已更新；服务尚未重启')
    print('后续手动执行 sudo systemctl restart op5-v3-fusion-8100')

def rollback():
    m=manifest()
    if not LEDGER.is_file() or not BACK.is_file():raise RuntimeError('没有有效的V3.1.3回退记录')
    ledger=json.loads(LEDGER.read_text('utf-8'))
    if (ledger.get('version')!=m['version'] or sha(BACK)!=m['old_core_sha256'] or
        sha(DST/'fusion_core.py')!=m['new_core_sha256'] or
        sha(DST/'service.py')!=ledger.get('service_sha') or
        sha(DST/'config.json')!=ledger.get('config_sha')):
        raise RuntimeError('源文件或配置已变化，拒绝盲目回退')
    guard_idle()
    replace(BACK,DST/'fusion_core.py')
    if sha(DST/'fusion_core.py')!=m['old_core_sha256']:raise RuntimeError('回退SHA校验失败')
    LEDGER.unlink()
    print('ROLLBACK SUCCESS: 恢复原V3.1核心，请自行重启8100')

if __name__=='__main__':
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true');g.add_argument('--apply',action='store_true');g.add_argument('--rollback',action='store_true')
    a=p.parse_args()
    try:
        if a.check:check()
        elif a.apply:apply()
        else:rollback()
    except Exception as exc:raise SystemExit('FAIL: '+str(exc))
