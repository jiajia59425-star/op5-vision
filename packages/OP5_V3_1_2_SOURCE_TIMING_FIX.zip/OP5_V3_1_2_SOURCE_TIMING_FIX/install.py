#!/usr/bin/env python3
"""Safe reversible upgrade of only the 8100 read-only service poll loop."""
import argparse, hashlib, json, os, shutil, stat, tempfile, time, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DST=Path('/home/orangepi/op5_v3_fusion')
UNIT=Path('/etc/systemd/system/op5-v3-fusion-8100.service')
BACK=DST/'backups'/'v312_service_before_source_timing.py'
LEDGER=DST/'.v312_source_timing_fix.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def manifest():
    m=json.loads((ROOT/'manifest.json').read_text('utf-8'))
    if m.get('version')!='OP5_V3_1_2_SOURCE_TIMING_FIX' or sha(ROOT/'service.py')!=m['new_service_sha256']:
        raise RuntimeError('安装包清单校验失败')
    compile((ROOT/'service.py').read_bytes(),'service.py','exec')
    return m
def state():
    m=manifest()
    if not UNIT.is_file() or '# OP5_V3_RADAR_VISION_FUSION_V1' not in UNIT.read_text('utf-8'):
        raise RuntimeError('8100 systemd服务不是预期版本')
    if not DST.is_dir() or not (DST/'config.json').is_file():raise RuntimeError('缺少8100数据目录或标定')
    for f in ('service.py','fusion_core.py'):
        if not (DST/f).is_file() or (DST/f).is_symlink():raise RuntimeError(f+'缺少或为软链接')
    if sha(DST/'fusion_core.py')!=m['fusion_core_sha256']:
        raise RuntimeError('现场融合核心已变更，不能自动覆盖')
    got=sha(DST/'service.py')
    if got==m['old_service_sha256'] and not LEDGER.exists():s='READY_TO_APPLY'
    elif got==m['new_service_sha256'] and LEDGER.exists():s='ALREADY_APPLIED'
    else:s='MISMATCH_OR_PARTIAL'
    return s,m

def check():
    s,m=state()
    print('8100 V3.1.2 采集时序修复 | 现场状态:',s)
    print('现场service SHA256:',sha(DST/'service.py'))
    print('8100标定config.json：保留；8093/8092/8081/8101：不修改')
    return s

def guard_idle():
    # Any communication failure is a no-go when about to replace service code.
    for port,path in ((8101,'/api/status'),(8093,'/api/auto/status')):
        with urllib.request.urlopen('http://127.0.0.1:%d%s'%(port,path),timeout=2) as r:
            obj=json.load(r)
        if port==8101 and (obj.get('armed') is not False or obj.get('stop_pending') is not False):
            raise RuntimeError('8101仍有控制会话或停机待确认，拒绝安装')
        if port==8093 and obj.get('active') is not False:
            raise RuntimeError('8093当前仍在跟踪，拒绝安装')

def replace(src,dst):
    st=dst.stat()
    fd,path=tempfile.mkstemp(prefix='.v312_stage_',dir=dst.parent)
    try:
        with os.fdopen(fd,'wb') as out:
            out.write(src.read_bytes());out.flush();os.fsync(out.fileno())
        os.chmod(path,stat.S_IMODE(st.st_mode))
        if os.geteuid()==0:os.chown(path,st.st_uid,st.st_gid)
        os.replace(path,dst)
    finally:
        if os.path.exists(path):os.unlink(path)

def apply():
    if check()!='READY_TO_APPLY':raise RuntimeError('请先处理版本不匹配，不允许覆盖')
    guard_idle()
    m=manifest()
    if BACK.exists():raise RuntimeError('固定回退备份已存在，拒绝覆盖')
    BACK.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(DST/'service.py',BACK)
    if sha(BACK)!=m['old_service_sha256']:raise RuntimeError('备份校验错误')
    info={'version':m['version'],'old':m['old_service_sha256'],'new':m['new_service_sha256'],
          'config_sha256':sha(DST/'config.json'),'created':time.strftime('%Y-%m-%d %H:%M:%S')}
    LEDGER.write_text(json.dumps(info,indent=2),'utf-8')
    try:
        replace(ROOT/'service.py',DST/'service.py')
        if sha(DST/'service.py')!=m['new_service_sha256'] or sha(DST/'config.json')!=info['config_sha256']:
            raise RuntimeError('升级后校验失败')
    except Exception:
        replace(BACK,DST/'service.py');LEDGER.unlink(missing_ok=True)
        raise
    print('INSTALL SUCCESS: 已备份并更新8100 service.py；尚未重启服务')
    print('重启命令: sudo systemctl restart op5-v3-fusion-8100')

def rollback():
    m=manifest()
    if not LEDGER.exists() or not BACK.is_file():raise RuntimeError('没有有效回退记录')
    info=json.loads(LEDGER.read_text('utf-8'))
    if sha(BACK)!=m['old_service_sha256'] or sha(DST/'service.py')!=m['new_service_sha256']:
        raise RuntimeError('现场文件已变化，拒绝盲目回退')
    guard_idle()
    replace(BACK,DST/'service.py')
    if sha(DST/'service.py')!=m['old_service_sha256']:raise RuntimeError('回退校验失败')
    LEDGER.unlink()
    print('ROLLBACK SUCCESS: 恢复原V3.1.1服务源码；需手动重启8100')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true');g.add_argument('--apply',action='store_true');g.add_argument('--rollback',action='store_true')
    a=p.parse_args()
    try:
        if a.check:check()
        elif a.apply:apply()
        else:rollback()
    except Exception as e:raise SystemExit('FAIL: '+str(e))
