#!/usr/bin/env python3
"""Non-invasive V3 deployer: no writes to 8081/8090/8092/8093, no motor commands."""
import argparse
import hashlib
import json
import pathlib
import shutil
import socket
import subprocess
import sys
import urllib.request

PKG=pathlib.Path(__file__).resolve().parent
DST=pathlib.Path('/home/orangepi/op5_v3_fusion')
UNIT=pathlib.Path('/etc/systemd/system/op5-v3-fusion-8100.service')
V2_SOURCE=pathlib.Path('/usr/local/lib/op5-gimbal-web-8093/server.py')
V2_TEMP=pathlib.Path('/usr/local/lib/op5-gimbal-web-8093/op5_temp_diag.py')
V2_EXPECT='69e8823ed889e565902ea097eeaaa6c4a3e5835c956ac8470d6daae6d51fb5ae'
TEMP_EXPECT='4a882158f1209b2016fbe116970d4fadbcc81d1c795e7253a00b265a23df8666'
MANIFEST=PKG/'sha256_manifest.json'
FILES=('fusion_core.py','service.py','dashboard.html','calibrate.py','config.example.json','diagnose.py')
MARK='# OP5_V3_RADAR_VISION_FUSION_V1'
UNIT_SOURCE=f'''{MARK}
[Unit]
Description=OP5 V3 COIN-D6 + YOLO Fusion Read Only 8100
After=network.target
Wants=network.target

[Service]
Type=simple
User=orangepi
WorkingDirectory={DST}
ExecStart=/usr/bin/python3 -u {DST}/service.py --port 8100 --listen 0.0.0.0
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=false
ReadOnlyPaths={DST}

[Install]
WantedBy=multi-user.target
'''


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def check(args, for_apply=False):
    print('===== V3只读融合安装前检查 =====')
    for p,want in ((V2_SOURCE,V2_EXPECT),(V2_TEMP,TEMP_EXPECT)):
        if not p.is_file():raise SystemExit('FAIL: 未找到稳定V2文件 '+str(p))
        got=sha(p);print(p.name,got)
        if got!=want:raise SystemExit('FAIL: V2现场版本改变，拒绝自动安装，请保留原程序并先核对')
    for f in FILES:
        p=PKG/f
        if not p.is_file():raise SystemExit('FAIL: 安装包缺少 '+f)
    if not MANIFEST.is_file():raise SystemExit('FAIL: 缺少SHA256清单')
    manifest=json.loads(MANIFEST.read_text('utf-8'))
    for f in FILES:
        if manifest.get(f)!=sha(PKG/f):raise SystemExit('FAIL: 安装包文件校验失败 '+f)
    for f in ('service.py','fusion_core.py','calibrate.py','diagnose.py'):
        compile((PKG/f).read_bytes(),str(PKG/f),'exec')
    if UNIT.exists():
        if MARK not in UNIT.read_text('utf-8'):
            raise SystemExit('FAIL: 8100服务名已被其他系统占用，不覆盖')
        print('已有V3服务单元；安装器不会覆盖，请先检查服务版本')
        if for_apply:raise SystemExit('FAIL: 不能重复应用，若需升级请先备份并使用新版升级工具')
    for service,url in [('8081视觉','http://127.0.0.1:8081/state'),
                        ('8092雷达','http://127.0.0.1:8092/api/scan'),
                        ('8093云台','http://127.0.0.1:8093/api/status')]:
        try:
            req=urllib.request.Request(url,headers={'Accept':'application/json'})
            with urllib.request.urlopen(req,timeout=2) as r:
                obj=json.loads(r.read(750000))
            if not isinstance(obj,dict):raise ValueError('不是JSON对象')
            if service.startswith('8092'):
                if 'points' not in obj:raise ValueError('/api/scan缺少points')
                print(service,'HTTP OK online=',obj.get('online'),'points=',len(obj.get('points') or []))
            elif service.startswith('8081'):
                if 'tracks' not in obj:raise ValueError('/state缺少tracks')
                print(service,'HTTP OK live=',obj.get('live'))
            else:
                if 'yaw' not in obj:raise ValueError('/api/status缺少yaw')
                print(service,'HTTP OK yaw=',obj['yaw'].get('angle'))
        except Exception as exc:
            raise SystemExit('FAIL: '+service+'读接口不兼容或暂时不可达：'+str(exc))
    if for_apply:
        with socket.socket() as s:
            s.settimeout(0.25)
            if s.connect_ex(('127.0.0.1',8100)) == 0:
                raise SystemExit('FAIL: 8100已经有服务监听；拒绝安装以免端口冲突')
    print('CHECK PASS: 没有修改文件，没有重启任何服务')


def install():
    check(None,True)
    if DST.exists() and any(DST.iterdir()):
        raise SystemExit('FAIL: 目标V3目录不是空的，请先核对，不覆盖已有文件')
    DST.mkdir(parents=True,exist_ok=True)
    for f in FILES:shutil.copy2(PKG/f,DST/f)
    shutil.copy2(PKG/'config.example.json',DST/'config.json')
    UNIT.write_text(UNIT_SOURCE,encoding='utf-8')
    for f in FILES:
        if sha(PKG/f)!=sha(DST/f):raise SystemExit('FAIL: 复制校验失败 '+f)
    print('INSTALL SUCCESS: V3文件已安装到',DST)
    print('服务单元:',UNIT)
    print('重要：未启动V3；8093/8092/8081/8090原服务均未修改或重启')
    print('下一步手动执行: sudo systemctl daemon-reload && sudo systemctl enable --now op5-v3-fusion-8100')


def rollback():
    if not UNIT.exists() or MARK not in UNIT.read_text('utf-8'):
        raise SystemExit('REFUSE: 不是本安装包创建的unit，不操作')
    subprocess.run(['systemctl','disable','--now','op5-v3-fusion-8100'],check=False)
    UNIT.unlink()
    subprocess.run(['systemctl','daemon-reload'],check=False)
    print('V3服务已停止并取消开机启动，unit已删除；V3源文件和标定配置均保留')
    print('8093的稳定V2、8092、8090没有改动，无需重启')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    x=p.add_mutually_exclusive_group(required=True)
    x.add_argument('--check',action='store_true')
    x.add_argument('--apply',action='store_true')
    x.add_argument('--rollback',action='store_true')
    args=p.parse_args()
    if args.check:check(args)
    elif args.apply:install()
    elif args.rollback:rollback()
