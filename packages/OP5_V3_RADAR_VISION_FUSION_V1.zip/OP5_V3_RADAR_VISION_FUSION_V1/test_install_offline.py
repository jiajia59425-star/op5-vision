import hashlib,importlib.util,json,pathlib,tempfile,unittest
from unittest.mock import patch
from io import BytesIO

spec=importlib.util.spec_from_file_location('v3installer',pathlib.Path(__file__).with_name('install.py'))
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class FakeResponse:
    def __init__(self,url):
        if '/api/scan' in url:
            self.raw={'online':True,'points':[[0,3,100]],'packets':5}
        elif ':8081' in url:self.raw={'tracks':[],'live':True}
        else:self.raw={'yaw':{'angle':0},'pitch':{'angle':0}}
    def read(self,n):return json.dumps(self.raw).encode()
    def __enter__(self):return self
    def __exit__(self,*a):pass

class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.root=pathlib.Path(self.t.name)
        for item,value in [('V2_SOURCE',self.root/'stable_server.py'),('V2_TEMP',self.root/'stable_temp.py'),
                           ('DST',self.root/'v3'),('UNIT',self.root/'v3.service')]:
            patcher=patch.object(mod,item,value);patcher.start();self.addCleanup(patcher.stop)
        mod.V2_SOURCE.write_bytes(b'original V2 server content')
        mod.V2_TEMP.write_bytes(b'original V2 temp module')
        for item,value in [('V2_EXPECT',mod.sha(mod.V2_SOURCE)),('TEMP_EXPECT',mod.sha(mod.V2_TEMP))]:
            patcher=patch.object(mod,item,value);patcher.start();self.addCleanup(patcher.stop)
        patcher=patch.object(mod.urllib.request,'urlopen',side_effect=lambda r,timeout=0:FakeResponse(r.full_url));patcher.start();self.addCleanup(patcher.stop)
    def test_check_is_read_only(self):
        before=(mod.sha(mod.V2_SOURCE),mod.sha(mod.V2_TEMP))
        mod.check(None)
        self.assertFalse(mod.DST.exists());self.assertFalse(mod.UNIT.exists())
        self.assertEqual(before,(mod.sha(mod.V2_SOURCE),mod.sha(mod.V2_TEMP)))
    def test_apply_create_only(self):
        mod.install();self.assertTrue(mod.UNIT.exists())
        self.assertIn(mod.MARK,mod.UNIT.read_text())
        self.assertEqual(json.loads((mod.DST/'config.json').read_text())['radar_zero_deg'],None)
    def test_apply_preserves_v2(self):
        before=(mod.sha(mod.V2_SOURCE),mod.sha(mod.V2_TEMP));mod.install()
        self.assertEqual(before,(mod.sha(mod.V2_SOURCE),mod.sha(mod.V2_TEMP)))
    def test_wrong_source_aborts(self):
        mod.V2_SOURCE.write_text('unexpected patch')
        with self.assertRaises(SystemExit):mod.check(None)
        self.assertFalse(mod.DST.exists())
    def test_existing_dir_aborts(self):
        mod.DST.mkdir();(mod.DST/'important').write_text('keep')
        with self.assertRaises(SystemExit):mod.install()
        self.assertEqual((mod.DST/'important').read_text(),'keep')
    def test_existing_unit_aborts(self):
        mod.UNIT.write_text('another service')
        with self.assertRaises(SystemExit):mod.install()
    def test_duplicate_apply_aborts(self):
        mod.install()
        with self.assertRaises(SystemExit):mod.install()
    def test_config_is_uncalibrated(self):
        mod.install();c=json.loads((mod.DST/'config.json').read_text())
        self.assertIsNone(c['radar_mount']);self.assertIsNone(c['camera_hfov_deg'])

if __name__=='__main__':unittest.main(verbosity=2)
