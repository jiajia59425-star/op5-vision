import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('v31_installer',Path(__file__).with_name('install.py'))
installer=importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)
BASE=Path(__file__).resolve().parent
REFERENCES={'fusion_core.py':'old_fusion_core_reference.py',
            'service.py':'baseline_service_reference.py',
            'dashboard.html':'baseline_dashboard_reference.html'}

class InstallTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)
        self.previous=(installer.DST,installer.UNIT)
        installer.DST=self.path/'op5_v3_fusion'
        installer.DST.mkdir()
        installer.UNIT=self.path/'op5-v3-fusion-8100.service'
        installer.UNIT.write_text(installer.MARK+'\n[Service]\n')
        for name in installer.FILES:
            (installer.DST/name).write_bytes((BASE/REFERENCES[name]).read_bytes())
        self.config=(installer.DST/'config.json')
        self.config.write_text('{"radar_zero_deg":351.5,"camera_hfov_deg":110,"radar_mount":"chassis","yaw_to_radar_sign":1}')
    def tearDown(self):
        installer.DST,installer.UNIT=self.previous
        self.tmp.cleanup()
    def test_check_is_read_only(self):
        before={f:installer.digest(installer.DST/f) for f in installer.FILES}
        self.assertEqual(installer.check(),'READY_TO_APPLY')
        self.assertEqual(before,{f:installer.digest(installer.DST/f) for f in installer.FILES})
    def test_install_only_three_files(self):
        initial=self.config.read_bytes()
        installer.apply()
        self.assertEqual(installer.get_state()[0],'ALREADY_APPLIED')
        self.assertEqual(self.config.read_bytes(),initial)
        self.assertTrue((installer.DST/installer.LEDGER).is_file())
    def test_apply_and_rollback_byte_identical(self):
        before={f:(installer.DST/f).read_bytes() for f in installer.FILES}
        installer.apply();installer.rollback()
        self.assertEqual({f:(installer.DST/f).read_bytes() for f in installer.FILES},before)
        self.assertEqual(installer.get_state()[0],'READY_TO_APPLY')
    def test_rollback_preserves_new_calibration(self):
        installer.apply()
        self.config.write_text('{"radar_zero_deg":349.5,"camera_hfov_deg":108}')
        installer.rollback()
        self.assertIn('349.5',self.config.read_text())
    def test_double_apply_refused(self):
        installer.apply()
        with self.assertRaises(RuntimeError):installer.apply()
    def test_unknown_edit_refused(self):
        (installer.DST/'fusion_core.py').write_text('edited')
        self.assertEqual(installer.get_state()[0],'UNRECOGNIZED_OR_PARTIAL')
        with self.assertRaises(RuntimeError):installer.apply()
    def test_rollback_refuses_extra_changes(self):
        installer.apply()
        (installer.DST/'fusion_core.py').write_text('user edit')
        with self.assertRaises(RuntimeError):installer.rollback()
    def test_rollback_refuses_no_ledger(self):
        with self.assertRaises(RuntimeError):installer.rollback()
    def test_recover_partial_prepared_install(self):
        installer.apply()
        data=json.loads((installer.DST/installer.LEDGER).read_text())
        data['stage']='prepared'
        (installer.DST/installer.LEDGER).write_text(json.dumps(data))
        installer.atomic_replace_from(Path(data['backup_dir'])/'service.py',installer.DST/'service.py')
        self.assertEqual(installer.get_state()[0],'PARTIAL_UPDATE_RESTORE_FIRST')
        installer.rollback()
        self.assertEqual(installer.get_state()[0],'READY_TO_APPLY')

if __name__=='__main__':unittest.main(verbosity=2)
