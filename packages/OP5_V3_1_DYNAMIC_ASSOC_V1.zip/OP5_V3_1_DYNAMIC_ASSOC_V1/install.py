#!/usr/bin/env python3
"""Strict and reversible V3.1 read-only fusion-only upgrade.

No motor, radar, or 8081/8092/8093 writes; not even a service restart.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile

PKG=Path(__file__).resolve().parent
DST=Path('/home/orangepi/op5_v3_fusion')
UNIT=Path('/etc/systemd/system/op5-v3-fusion-8100.service')
MARK='# OP5_V3_RADAR_VISION_FUSION_V1'
LEDGER='.v31_rollback.json'
FILES=('fusion_core.py','service.py','dashboard.html')
SHA=PKG/'version_manifest.json'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def manifest():
    x=json.loads(SHA.read_text('utf-8'))
    if x.get('version')!='OP5_V3_1_DYNAMIC_ASSOC_V1':
        raise RuntimeError('升级清单版本不匹配')
    for name in FILES:
        if digest(PKG/name)!=x['new'][name]:
            raise RuntimeError('安装包SHA256校验失败: '+name)
        if name.endswith('.py'):
            compile((PKG/name).read_bytes(),name,'exec')
    return x

def get_state():
    x=manifest()
    if not DST.is_dir():raise RuntimeError('尚未安装原V3平台目录: '+str(DST))
    if not UNIT.is_file() or MARK not in UNIT.read_text('utf-8'):
        raise RuntimeError('8100服务不是原V3受控服务，拒绝操作')
    for name in FILES:
        p=DST/name
        if not p.is_file() or p.is_symlink():
            raise RuntimeError('现场缺少文件或发现软链接，拒绝操作: '+str(p))
    if not (DST/'config.json').is_file():
        raise RuntimeError('缺少原标定config.json，拒绝操作')
    current={name:digest(DST/name) for name in FILES}
    if all(current[n]==x['old'][n] for n in FILES):
        state='READY_TO_APPLY'
    elif all(current[n]==x['new'][n] for n in FILES):
        state='ALREADY_APPLIED'
    else:state='UNRECOGNIZED_OR_PARTIAL'
    ledger=DST/LEDGER
    if ledger.exists() and state=='READY_TO_APPLY':state='RESTORE_RECORD_PRESENT'
    if ledger.exists() and state=='UNRECOGNIZED_OR_PARTIAL':state='PARTIAL_UPDATE_RESTORE_FIRST'
    return state,current,x

def check():
    state,current,x=get_state()
    print('===== V3.1动态关联：只读检查 =====')
    print('现场状态:',state)
    for name in FILES:
        print(name,'现场:',current[name], '| V3.1:',x['new'][name])
    print('现有标定配置:',DST/'config.json','(不会修改)')
    print('原8093高速预测V2 / 8081 / 8092 / 8090：均不会修改')
    print('CHECK PASS: 只读校验，无文件改动或服务重启')
    return state

def atomic_replace_from(src,dst):
    mode=dst.stat().st_mode
    fd,tmp=tempfile.mkstemp(prefix='.v31_stage_',dir=str(dst.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(src.read_bytes())
            f.flush();os.fsync(f.fileno())
        os.chmod(tmp,stat.S_IMODE(mode))
        if os.geteuid()==0:
            st=dst.stat();os.chown(tmp,st.st_uid,st.st_gid)
        os.replace(tmp,dst)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def apply():
    state=check()
    if state!='READY_TO_APPLY':
        raise RuntimeError('只能从未修改的V3初版升级；状态='+state)
    x=manifest()
    cfg_before=digest(DST/'config.json')
    backup=DST/'backups'/('dynamic_assoc_v31_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    backup.mkdir(parents=True,exist_ok=False)
    for name in FILES:
        shutil.copy2(DST/name,backup/name)
        if digest(backup/name)!=x['old'][name]:
            raise RuntimeError('创建备份时SHA不匹配: '+name)
    ledger=DST/LEDGER
    # Record before first overwrite so interruptions are recoverable.
    data={'version':x['version'],'stage':'prepared','backup_dir':str(backup),
          'old':x['old'],'new':x['new'],'config_sha256':cfg_before}
    fd,tmp=tempfile.mkstemp(prefix='.v31_ledger_',dir=str(DST))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,ledger)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    try:
        for name in FILES:
            atomic_replace_from(PKG/name,DST/name)
            if digest(DST/name)!=x['new'][name]:
                raise RuntimeError('安装后SHA不匹配: '+name)
        if digest(DST/'config.json')!=cfg_before:
            raise RuntimeError('标定配置意外改变，请停止操作')
        data['stage']='applied'
        ledger.write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8')
    except Exception:
        rollback()
        raise
    print('INSTALL SUCCESS: V3.1核心/服务/界面已写入磁盘，尚未重启8100')
    print('原V3备份目录:',backup)
    print('原标定配置SHA256:',cfg_before)
    print('只需手动执行: sudo systemctl restart op5-v3-fusion-8100')

def rollback():
    ledger=DST/LEDGER
    if not ledger.is_file():raise RuntimeError('没有V3.1升级回退记录，拒绝回退')
    data=json.loads(ledger.read_text('utf-8'))
    if data.get('version')!='OP5_V3_1_DYNAMIC_ASSOC_V1':
        raise RuntimeError('回退记录的版本不匹配')
    backup=Path(data['backup_dir'])
    if not backup.is_dir() or backup.parent!=(DST/'backups'):
        raise RuntimeError('备份路径与预期不符')
    for name in FILES:
        if digest(backup/name)!=data['old'][name]:
            raise RuntimeError('原V3备份校验失败: '+name)
        current=digest(DST/name)
        if current not in (data['old'][name],data['new'][name]):
            raise RuntimeError('现场文件发生额外修改，拒绝覆盖: '+name)
    for name in FILES:
        if digest(DST/name)!=data['old'][name]:
            atomic_replace_from(backup/name,DST/name)
        if digest(DST/name)!=data['old'][name]:
            raise RuntimeError('回退后SHA不匹配: '+name)
    ledger.unlink()
    print('ROLLBACK SUCCESS: V3初版三个文件已从备份恢复，服务未重启')
    print('下一步手动执行: sudo systemctl restart op5-v3-fusion-8100')
    print('config.json标定参数与8081/8092/8093/8090均未修改')

if __name__=='__main__':
    p=argparse.ArgumentParser(description='V3.1融合动态关联严格升级 / 回退')
    actions=p.add_mutually_exclusive_group(required=True)
    actions.add_argument('--check',action='store_true')
    actions.add_argument('--apply',action='store_true')
    actions.add_argument('--rollback',action='store_true')
    opts=p.parse_args()
    try:
        if opts.check:check()
        elif opts.apply:apply()
        elif opts.rollback:rollback()
    except Exception as exc:
        raise SystemExit('FAIL: '+str(exc))
